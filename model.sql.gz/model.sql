-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 12, 2020 at 09:25 AM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.4.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `torque`
--

-- --------------------------------------------------------

--
-- Table structure for table `model`
--

CREATE TABLE `model` (
  `Model_ID` int(11) NOT NULL,
  `Company_ID` int(11) NOT NULL,
  `Category_ID` int(11) NOT NULL,
  `Seats` int(2) NOT NULL,
  `Launch Date` date NOT NULL,
  `Description` text NOT NULL,
  `Fuel type` varchar(20) NOT NULL,
  `Price` varchar(20) NOT NULL,
  `Name` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `model`
--

INSERT INTO `model` (`Model_ID`, `Company_ID`, `Category_ID`, `Seats`, `Launch Date`, `Description`, `Fuel type`, `Price`, `Name`) VALUES
(20, 71, 50, 4, '2018-08-15', 'BMW 7 SERIES :The BMW 7 Series is a full-size luxury sedan produced by the German automaker BMW since 1977.', 'Diesel', '1 C', 'BMW 7 series'),
(21, 70, 51, 6, '2019-12-18', 'Mercedes GLE : Dimensionally, the Mercedes Benz GLE Class comes with a length of 4819mm, width of 2141mm and height of 1796mm along with wheelbase of 2915mm.', 'Diesel', '80 L', 'Mercedes Benz GLE'),
(22, 71, 50, 4, '2019-11-14', 'BMW 6 series : The BMW 6 Series is a range of grand tourers produced by BMW since 1976. It is the successor to the E9 Coupé and is currently in its fourth generation.', 'Diesel', '85 L', 'BMW 6 series');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `model`
--
ALTER TABLE `model`
  ADD PRIMARY KEY (`Model_ID`),
  ADD KEY `Category_ID` (`Category_ID`),
  ADD KEY `Company_ID` (`Company_ID`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `model`
--
ALTER TABLE `model`
  ADD CONSTRAINT `model_ibfk_1` FOREIGN KEY (`Category_ID`) REFERENCES `category` (`Category_ID`),
  ADD CONSTRAINT `model_ibfk_2` FOREIGN KEY (`Company_ID`) REFERENCES `cars_company` (`Company ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
